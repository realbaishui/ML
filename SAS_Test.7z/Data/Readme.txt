This folder contains all of the external data used in book "�������SAS".
Please put it in a folder, and then change the location in libname statement in each programs.